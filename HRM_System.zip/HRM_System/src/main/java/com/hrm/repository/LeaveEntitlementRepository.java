
package com.hrm.repository;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.hrm.model.LeaveEntitlement;

public interface LeaveEntitlementRepository
        extends JpaRepository<LeaveEntitlement, Long> {

    @Query("""
        SELECT le
        FROM LeaveEntitlement le
        JOIN FETCH le.employee
        JOIN FETCH le.leaveType
        WHERE le.employee.employeeId = :employeeId
        ORDER BY le.periodStart DESC
        """)
    List<LeaveEntitlement> findByEmployeeId(
            @Param("employeeId") Long employeeId);

    @Query("""
        SELECT CASE WHEN COUNT(le) > 0
                    THEN true ELSE false END
        FROM LeaveEntitlement le
        WHERE le.employee.employeeId = :employeeId
        AND le.leaveType.leaveTypeId = :leaveTypeId
        AND le.periodStart < :periodEnd
        AND le.periodEnd > :periodStart
        """)
    boolean existsOverlappingPeriod(
            @Param("employeeId") Long employeeId,
            @Param("leaveTypeId") Long leaveTypeId,
            @Param("periodStart") LocalDate periodStart,
            @Param("periodEnd") LocalDate periodEnd);
}
